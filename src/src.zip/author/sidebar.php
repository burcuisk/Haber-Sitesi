<!-- Sidebar -->
		<div class="sidebar">
			<div class="sidebar-content">

				<!-- Main navigation -->
				<ul class="navigation">
					<li class="active"><a href="index.php "><span>Dashboard</span> <i class="icon-screen2"></i></a></li>
					<li>
						<a href="#"><span>News</span> <i class="icon-paragraph-justify2"></i></a>
						<ul>
							<li><a href="publish.php">Publish news</a></li>
							<li><a href="editnews.php">Edit News</a></li>
							<li>
						<a href="#"><span>News Details</span></a>
						<ul>
							<li><a href="addnewsphoto.php">Add News Photo</a></li>
							<!--<li><a href="editnewscategories">Edit news categories</a></li> -->
						</ul>
					</li>
						</ul>
					</li>
					<li>
						<a href="#"><span>Comments</span> <i class="icon-grid"></i></a>
						<ul>
							<li><a href="editcomments.php">Edit News Comments</a></li>
						</ul>
					</li>
					<li>
						
				</ul>
				<!-- /main navigation -->
				
			</div>
		</div>
		<!-- /sidebar -->