  <div class="right sidebar" id="sidebar">
        <div class="section">
          <div class="section-title">
            <div class="left">Latest News</div>
            <div class="right"><img src="img/icon-time.gif" width="14" height="14" alt="" /></div>
            <div class="clearer">&nbsp;</div>
          </div>
          <div class="section-content">
            <ul class="nice-list">
              <li>
                <div class="left"><a href="#">Aenean tempor arcu..</a></div>
                <div class="right">20.49</div>
                <div class="clearer">&nbsp;</div>
              </li>
              <li>
                <div class="left"><a href="#">Justo interdum rutrum</a></div>
                <div class="right">20:40</div>
                <div class="clearer">&nbsp;</div>
              </li>
              <li>
                <div class="left"><a href="#">In nec justo in urna</a></div>
                <div class="right">19:56</div>
                <div class="clearer">&nbsp;</div>
              </li>
              <li>
                <div class="left"><a href="#">Accumsan condimentum</a></div>
                <div class="right">19:15</div>
                <div class="clearer">&nbsp;</div>
              </li>
              <li>
                <div class="left"><a href="#">Etiam commodo bibendum</a></div>
                <div class="right">19:06</div>
                <div class="clearer">&nbsp;</div>
              </li>
              <li>
                <div class="left"><a href="#">Mauris euismod justo</a></div>
                <div class="right">18:51</div>
                <div class="clearer">&nbsp;</div>
              </li>
              <li><a href="#" class="more">Browse all &#187;</a></li>
            </ul>
          </div>
        </div>
        <div class="section">
          <div class="section-title">Latest Comments</div>
          <div class="section-content">
            <ul class="nice-list">
              <li><span class="quiet">1.</span> <a href="#">Integer diam elit</a></li>
              <li><span class="quiet">2.</span> <a href="#">Condimentum ac semper</a></li>
              <li><span class="quiet">3.</span> <a href="#">Tincidunt non diam</a></li>
              <li><span class="quiet">4.</span> <a href="#">Ut congue rutrum</a></li>
              <li><span class="quiet">5.</span> <a href="#">Enim dapibus venenatis</a></li>
              <li><span class="quiet">6.</span> <a href="#">Cras hendrerit iaculis</a></li>
              <li><span class="quiet">7.</span> <a href="#">Duis mi lectus</a></li>
              <li><span class="quiet">8.</span> <a href="#">Eleifend nec tortor</a></li>
			  <li><span class="quiet">9.</span> <a href="#">Eleifend nec tortor</a></li>
			  <li><span class="quiet">10	.</span> <a href="#">Eleifend nec tortor</a></li>
        
            </ul>
          </div>
        </div>
        
		
		<div class="section network-section">
          <div class="section-title">Network News</div>
          <div class="section-content">
            <ul class="nice-list">
              <li><a href="#">Nullam eros</a></li>
              <li><a href="#">Eleifend nec tortor</a></li>
              <li><a href="#">Duis mi lectus</a></li>
              <li><a href="#">Integer diam elit</a></li>
              <li><a href="#">Enim dapibus venenatis</a></li>
              <li><a href="#" class="more">Visit Network Site &#187;</a></li>
            </ul>
          </div>
        </div>
		
				<div class="section network-section">
          <div class="section-title">Network News</div>
          <div class="section-content">
            <ul class="nice-list">
              <li><a href="#">Nullam eros</a></li>
              <li><a href="#">Eleifend nec tortor</a></li>
              <li><a href="#">Duis mi lectus</a></li>
              <li><a href="#">Integer diam elit</a></li>
              <li><a href="#">Enim dapibus venenatis</a></li>
              <li><a href="#" class="more">Visit Network Site &#187;</a></li>
            </ul>
          </div>
        </div>
		
				<div class="section network-section">
          <div class="section-title">Network News</div>
          <div class="section-content">
            <ul class="nice-list">
              <li><a href="#">Nullam eros</a></li>
              <li><a href="#">Eleifend nec tortor</a></li>
              <li><a href="#">Duis mi lectus</a></li>
              <li><a href="#">Integer diam elit</a></li>
              <li><a href="#">Enim dapibus venenatis</a></li>
              <li><a href="#" class="more">Visit Network Site &#187;</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="clearer">&nbsp;</div>